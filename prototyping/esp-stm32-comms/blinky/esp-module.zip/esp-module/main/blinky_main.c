#include <stdio.h>
#include "freertos/FreeRTOS.h"
#include "freertos/task.h"
#include "driver/spi.h"

void app_main() {
    printf("Starting minimal init\n");

    spi_config_t spi_config = {
        .interface.val = SPI_DEFAULT_INTERFACE,
        .intr_enable.val = 0,
        .mode = SPI_MASTER_MODE,
        .clk_div = SPI_10MHz_DIV,
        .event_cb = NULL
    };

    spi_config.interface.cs_en = 0;

    vTaskDelay(1000 / portTICK_PERIOD_MS);

    esp_err_t ret = spi_init(HSPI_HOST, &spi_config);

    vTaskDelay(1000 / portTICK_PERIOD_MS);

    if (ret == ESP_OK) {
        printf("SPI initialized successfully\n");
    } else {
        printf("SPI init failed %d\n", ret);
    }
	

    while (true) {
        printf("We are here\n");
        vTaskDelay(1000 / portTICK_PERIOD_MS);
    }

}
